<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail</title>
</head>
<body>
<p>Your password change has been initiated. Here is your pin number:</p>
<?php
        echo $_content;
    ?>
</body>
</html>
<?php /**PATH C:\Apache24_php8\htdocs\spnhs_yearbook\resources\views/mail-template/index.blade.php ENDPATH**/ ?>