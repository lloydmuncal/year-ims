<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        @page {
            size: A4;
            margin: 0;
        }

        body {
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .cover-page,
        .page-container {
            position: relative;
            height: 100%;
        }

        .cover-page {
            background-image: url('data:image/jpeg;base64,<?php echo e(base64_encode($cover)); ?>');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .page-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .overlay-image {
            position: absolute;
            /* Set other common styles as needed */
            width: 75px;
            height: 105px;
        }


    </style>
</head>
<body>
    <div class="cover-page"></div>
    <?php $__currentLoopData = $pagesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="page-container">
            <img src="data:image/jpeg;base64,<?php echo e(base64_encode($page['background'])); ?>" alt="Page Image">
            <?php $__currentLoopData = $page['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($index === 0): ?>
                    <img src="data:image/jpeg;base64,<?php echo e(base64_encode($image['data'])); ?>" alt="Overlay Image" class="overlay-image position-<?php echo e($index); ?>" style="width: 37%; height: 35%; top: 18%; left: 9%; border: 2px solid #888;">
                <?php elseif($index === 1): ?>
                    <img src="data:image/jpeg;base64,<?php echo e(base64_encode($image['data'])); ?>" alt="Overlay Image" class="overlay-image position-<?php echo e($index); ?>" style="width: 37%; height: 35%; top: 18%; left: 54%; border: 2px solid #888;">
                <?php elseif($index === 2): ?>
                    <img src="data:image/jpeg;base64,<?php echo e(base64_encode($image['data'])); ?>" alt="Overlay Image" class="overlay-image position-<?php echo e($index); ?>" style="width: 37%; height: 35%; top: 58%; left: 9%; border: 2px solid #888;">
                <?php elseif($index === 3): ?>
                    <img src="data:image/jpeg;base64,<?php echo e(base64_encode($image['data'])); ?>" alt="Overlay Image" class="overlay-image position-<?php echo e($index); ?>" style="width: 37%; height: 35%; top: 58%; left: 54%; border: 2px solid #888;">
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\yearbook2\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>