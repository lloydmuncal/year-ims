<template>
    <div class=" flex justify-center w-32">
        <img src="../../Asset/ZKZg.gif"  />
    </div>
</template>
<script>
    export default {
        props:[''],
        data() {
            return {
                key: null
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>
