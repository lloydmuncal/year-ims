<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BackupController extends Controller
{
      public function createBackup()
    {
        return 'Backup Successfully';
    }
}



